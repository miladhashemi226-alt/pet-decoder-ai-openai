
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import {
  PawPrint,
  Zap,
  Shield,
  Heart,
  Sparkles,
  CheckCircle,
  ArrowRight,
  Upload,
  TrendingUp,
  Lock,
  Globe,
  Brain,
  Star,
  MessageCircle,
  Bell,
  BookOpen,
  Activity,
  Calendar,
  Award,
  Target,
  Users,
  Clock,
  Play,
  ChevronRight,
  Syringe,
  History,
  LineChart,
  Gift,
  Mic,
  Lightbulb,
  AlertCircle,
  Check,
  X,
  Video,
  Image as ImageIcon,
  ChevronDown,
  Smile,
  Frown,
  Meh,
  AlertTriangle,
  Info
} from "lucide-react";
import { motion, useScroll, useTransform, AnimatePresence } from "framer-motion";
import SEO from "../components/common/SEO";
import AppLogo from "../components/common/AppLogo";
import CookieConsent from "../components/common/CookieConsent";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function Landing() {
  const [showStickyBar, setShowStickyBar] = useState(false);
  const [activeTab, setActiveTab] = useState("video");
  const { scrollY } = useScroll();

  useEffect(() => {
    const handleScroll = () => {
      setShowStickyBar(window.scrollY > 600);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleGetStarted = async () => {
    try {
      const currentUrl = window.location.origin + createPageUrl("Onboarding");
      await User.loginWithRedirect(currentUrl);
    } catch (error) {
      console.error("Login error:", error);
    }
  };

  const handleTryNow = () => {
    // Navigate to analyze page directly - users can try without signup
    window.location.href = createPageUrl("Analyze");
  };

  const features = [
    {
      icon: Brain,
      title: "AI-Powered Analysis",
      description: "Advanced computer vision analyzes body language, facial expressions, posture, and movement patterns from photos or videos up to 2 minutes long.",
      gradient: "from-purple-500 to-indigo-500",
      benefit: "Instant insights"
    },
    {
      icon: Video,
      title: "Video Frame Extraction",
      description: "Automatically extracts key frames from videos to analyze behavioral changes over time, providing temporal context for more accurate emotion detection.",
      gradient: "from-blue-500 to-cyan-500",
      benefit: "Comprehensive analysis"
    },
    {
      icon: Mic,
      title: "Audio Behavior Guidance",
      description: "Get expert recommendations on what vocalizations to listen for based on observed visual behavior patterns in videos.",
      gradient: "from-emerald-500 to-teal-500",
      benefit: "Multi-sensory insights"
    },
    {
      icon: LineChart,
      title: "Behavior Tracking",
      description: "Track emotional patterns over time with visual charts. Monitor changes in your pet's wellbeing and identify trends early.",
      gradient: "from-orange-500 to-red-500",
      benefit: "Long-term monitoring"
    },
    {
      icon: Bell,
      title: "Smart Alerts",
      description: "Receive notifications when unusual behavioral patterns are detected, helping you respond quickly to potential concerns.",
      gradient: "from-pink-500 to-rose-500",
      benefit: "Early warning system"
    },
    {
      icon: Syringe,
      title: "Health Reminders",
      description: "Never miss important vaccinations or health checkups with automated reminders for DHPP, Rabies, FVRCP, and other vaccines.",
      gradient: "from-violet-500 to-purple-500",
      benefit: "Health management"
    },
    {
      icon: MessageCircle,
      title: "AI Expert Chat",
      description: "Ask questions about your pet's behavior and get AI-powered responses based on animal behavior research and your pet's history.",
      gradient: "from-cyan-500 to-blue-500",
      benefit: "24/7 guidance"
    },
    {
      icon: Shield,
      title: "Privacy First",
      description: "Your data is encrypted, never sold, and never used for AI training. Full GDPR, CCPA, and PIPEDA compliance with right to deletion.",
      gradient: "from-green-500 to-emerald-500",
      benefit: "Total control"
    }
  ];

  const howItWorks = [
    {
      step: 1,
      title: "Upload Media",
      description: "Take a photo or record a video (up to 2 minutes) of your pet showing the behavior you want to understand.",
      icon: Upload,
      color: "from-purple-500 to-blue-500",
      detail: "Supports JPG, PNG, MP4, MOV formats"
    },
    {
      step: 2,
      title: "AI Processing",
      description: "Our AI extracts frames, analyzes body language indicators, and processes behavioral cues using computer vision.",
      icon: Brain,
      color: "from-blue-500 to-cyan-500",
      detail: "Analysis completes in under 60 seconds"
    },
    {
      step: 3,
      title: "Receive Insights",
      description: "Get comprehensive analysis with emotion detection, confidence scores, possible reasons, and expert recommendations.",
      icon: Lightbulb,
      color: "from-green-500 to-emerald-500",
      detail: "Detailed breakdown of findings"
    },
    {
      step: 4,
      title: "Track Over Time",
      description: "Monitor behavioral trends, receive alerts for changes, and use insights to improve your pet's wellbeing.",
      icon: TrendingUp,
      color: "from-orange-500 to-red-500",
      detail: "Historical data and patterns"
    }
  ];

  const comparisonData = [
    {
      feature: "Cost",
      traditional: "$150-300/visit",
      petDecoder: "Free",
      petDecoderBest: true
    },
    {
      feature: "Availability",
      traditional: "Business hours only",
      petDecoder: "24/7 Access",
      petDecoderBest: true
    },
    {
      feature: "Analysis Speed",
      traditional: "Days to weeks",
      petDecoder: "< 60 seconds",
      petDecoderBest: true
    },
    {
      feature: "Video Analysis",
      traditional: "Not available",
      petDecoder: "Multi-frame extraction",
      petDecoderBest: true
    },
    {
      feature: "Behavior Tracking",
      traditional: "Manual notes",
      petDecoder: "Automated charts",
      petDecoderBest: true
    },
    {
      feature: "Historical Data",
      traditional: "Limited records",
      petDecoder: "Full history",
      petDecoderBest: true
    },
    {
      feature: "Replaces Vet?",
      traditional: "No",
      petDecoder: "No - Complementary tool",
      petDecoderBest: false
    }
  ];

  const faqs = [
    {
      question: "Is Pet Decoder AI really free?",
      answer: "Yes, completely free with no hidden costs, no credit card required, and no premium tiers. All features are available to everyone at no charge. This is a passion project to help pet parents understand their pets better."
    },
    {
      question: "How accurate is the AI?",
      answer: "Our AI analyzes multiple behavioral indicators including body language, facial expressions, and posture. Results include confidence scores (0-100%) so you know the reliability. However, AI analysis is not perfect and should never replace professional veterinary advice, especially for health concerns."
    },
    {
      question: "What can I upload?",
      answer: "Photos (JPG, PNG) or videos up to 2 minutes long (MP4, MOV). Videos are better for comprehensive analysis as the AI can observe behavioral changes over time. Maximum file size is 100MB."
    },
    {
      question: "Is my data safe?",
      answer: "Yes. We use AES-256 encryption, comply with GDPR/CCPA/PIPEDA, and your data is NEVER used for AI training or sold. You can delete your account and all data anytime. Full transparency in our privacy policy."
    },
    {
      question: "Does it work for cats and dogs?",
      answer: "Yes, the AI is trained on behavioral patterns for both dogs and cats. It understands species-specific body language, facial expressions, and behavioral cues unique to each animal."
    },
    {
      question: "Can this replace my veterinarian?",
      answer: "Absolutely not. Pet Decoder AI is an educational tool to help you understand behavior, not a medical diagnostic tool. Always consult a licensed veterinarian for health concerns, emergencies, or medical advice."
    },
    {
      question: "What if the AI is wrong?",
      answer: "AI is not perfect. That's why we include confidence scores with each analysis. Low confidence scores mean the AI is uncertain. Use results as a starting point for understanding, not absolute truth. When in doubt, consult a professional."
    },
    {
      question: "Do I need to create an account?",
      answer: "No! You can try the analysis feature immediately without any signup. Creating an account (free) unlocks additional features like history tracking, trend analysis, and personalized insights."
    },
    {
      question: "How long does analysis take?",
      answer: "Most analyses complete in under 60 seconds. Video processing takes slightly longer as the AI extracts and analyzes multiple frames, but typically still under a minute."
    },
    {
      question: "What if I want my data deleted?",
      answer: "You have full control. Go to Settings and request account deletion. All your data (profiles, analyses, uploads) will be permanently deleted within 30 days. This is your GDPR 'right to be forgotten.'"
    }
  ];

  const emotionExamples = [
    {
      emotion: "Happy/Playful",
      indicators: ["Relaxed body", "Loose tail wag", "Open mouth (dogs)", "Forward ears", "Bright eyes"],
      icon: Smile,
      color: "text-green-600"
    },
    {
      emotion: "Anxious/Stressed",
      indicators: ["Low body posture", "Tail tucked", "Whale eye (whites showing)", "Ears back", "Lip licking"],
      icon: Frown,
      color: "text-yellow-600"
    },
    {
      emotion: "Aggressive/Defensive",
      indicators: ["Stiff body", "Direct stare", "Raised hackles", "Bared teeth", "Tense posture"],
      icon: AlertTriangle,
      color: "text-red-600"
    },
    {
      emotion: "Neutral/Calm",
      indicators: ["Relaxed stance", "Natural tail position", "Soft eyes", "Normal ear position", "Steady breathing"],
      icon: Meh,
      color: "text-blue-600"
    }
  ];

  const schema = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "Pet Decoder AI",
    "applicationCategory": "UtilitiesApplication",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    },
    "operatingSystem": "Web",
    "description": "Free AI-powered pet behavior analysis tool. Upload photos or videos to get instant insights into your pet's emotions and body language. Features include behavior tracking, smart alerts, vaccine reminders, and AI expert chat.",
    "author": {
      "@type": "Organization",
      "name": "Pet Decoder AI"
    }
  };

  return (
    <>
      <SEO
        title="Pet Decoder AI - Free AI Pet Behavior Analysis Tool"
        description="Upload photos or videos of your pet and get instant AI-powered insights into their emotions and body language. Completely free with behavior tracking, alerts, and expert guidance."
        keywords="pet behavior analysis, AI pet decoder, dog behavior, cat behavior, pet emotions, free pet app, animal behavior analysis"
        ogImage="https://images.unsplash.com/photo-1450778869180-41d0601e046e?w=1200&h=630&fit=crop"
        canonicalUrl="https://yourapp.base44.com/"
        schema={schema}
      />
      
      {/* Cookie Consent Popup */}
      <CookieConsent />

      {/* Sticky Top Bar */}
      <motion.div
        initial={{ y: -100 }}
        animate={{ y: showStickyBar ? 0 : -100 }}
        transition={{ duration: 0.3 }}
        className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-md border-b border-purple-100 z-50 shadow-lg"
      >
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <AppLogo size="sm" />
            <span className="font-bold text-lg hidden md:inline">Pet Decoder AI</span>
            <Badge className="bg-green-100 text-green-700 border-green-200 font-semibold">
              <Gift className="w-3 h-3 mr-1" />
              100% Free
            </Badge>
          </div>
          <Button
            onClick={handleTryNow}
            className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white shadow-lg"
          >
            Try Now
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </motion.div>

      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
        {/* Navigation */}
        <nav className="bg-white/80 backdrop-blur-sm border-b border-purple-100 sticky top-0 z-40" role="navigation" aria-label="Main navigation">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <AppLogo size="md" />
                <span className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                  Pet Decoder AI
                </span>
              </div>
              <div className="flex items-center gap-4">
                <button
                  onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
                  className="hidden md:inline text-gray-700 hover:text-purple-600 transition-colors font-medium"
                >
                  Features
                </button>
                <button
                  onClick={() => document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' })}
                  className="hidden md:inline text-gray-700 hover:text-purple-600 transition-colors font-medium"
                >
                  How It Works
                </button>
                <button
                  onClick={() => document.getElementById('faq')?.scrollIntoView({ behavior: 'smooth' })}
                  className="hidden md:inline text-gray-700 hover:text-purple-600 transition-colors font-medium"
                >
                  FAQ
                </button>
                <Button
                  onClick={handleTryNow}
                  className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white shadow-lg hover:shadow-xl transition-all"
                >
                  Try It Free
                </Button>
              </div>
            </div>
          </div>
        </nav>

        {/* Hero Section */}
        <section className="pt-20 pb-16 px-6 relative overflow-hidden bg-gradient-to-br from-purple-600 via-blue-600 to-purple-600" aria-labelledby="hero-heading">
          <div className="absolute inset-0 bg-grid-pattern opacity-[0.05]" />
          
          <div className="container mx-auto max-w-7xl relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center max-w-5xl mx-auto"
            >
              {/* Trust Indicators */}
              <div className="flex items-center justify-center gap-4 mb-6 flex-wrap">
                <Badge className="bg-white/20 backdrop-blur-sm text-white border-white/30 text-sm font-semibold px-4 py-2">
                  <Shield className="w-4 h-4 mr-1" />
                  GDPR Compliant
                </Badge>
                <Badge className="bg-white/20 backdrop-blur-sm text-white border-white/30 text-sm font-semibold px-4 py-2">
                  <Lock className="w-4 h-4 mr-1" />
                  AES-256 Encrypted
                </Badge>
                <Badge className="bg-green-500/90 text-white border-none text-sm font-bold px-4 py-2 shadow-lg">
                  <Gift className="w-4 h-4 mr-1" />
                  100% Free
                </Badge>
              </div>

              <h1 id="hero-heading" className="text-4xl md:text-6xl lg:text-7xl font-black mb-6 leading-tight text-white">
                Understand Your Pet's
                <br />
                <span className="bg-gradient-to-r from-yellow-300 via-pink-300 to-yellow-300 bg-clip-text text-transparent animate-gradient bg-[length:200%_auto]">
                  Body Language
                </span>
              </h1>

              <p className="text-xl md:text-2xl text-white/95 mb-8 leading-relaxed max-w-3xl mx-auto font-light">
                Upload a photo or video and get <strong className="font-bold">instant AI-powered analysis</strong> of your pet's emotions, behavior, and body language. <strong className="font-bold text-yellow-300">Completely free.</strong>
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
                <Button
                  onClick={handleTryNow}
                  size="lg"
                  className="bg-white text-purple-600 hover:bg-gray-100 text-lg px-12 py-7 shadow-2xl hover:shadow-white/50 transition-all duration-300 group font-bold rounded-2xl"
                >
                  <Zap className="w-6 h-6 mr-2 group-hover:animate-pulse" />
                  Try It Now - No Signup
                  <ArrowRight className="w-6 h-6 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
                <Button
                  onClick={handleGetStarted}
                  variant="outline"
                  size="lg"
                  className="text-lg px-12 py-7 border-2 border-white/30 bg-white/10 backdrop-blur-sm text-white hover:bg-white/20 font-semibold rounded-2xl"
                >
                  <Users className="w-5 h-5 mr-2" />
                  Sign Up for Full Access
                </Button>
              </div>

              <div className="flex items-center justify-center gap-6 text-sm text-white/90 flex-wrap">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-300" />
                  <span className="font-medium">No credit card</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-300" />
                  <span className="font-medium">No signup required to try</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-300" />
                  <span className="font-medium">Results in under 60s</span>
                </div>
              </div>
            </motion.div>

            {/* Hero Visual - Process Preview */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.3 }}
              className="mt-16 max-w-5xl mx-auto"
            >
              <Card className="border-none shadow-2xl overflow-hidden bg-white/95 backdrop-blur-sm">
                <CardContent className="p-0">
                  <div className="aspect-[16/9] bg-gradient-to-br from-purple-100 via-white to-blue-100 relative overflow-hidden">
                    <div className="absolute inset-0 bg-grid-pattern opacity-5" />
                    
                    <div className="relative z-10 h-full flex items-center justify-center p-6">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full max-w-4xl">
                        <motion.div
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.6 }}
                          className="bg-white rounded-xl p-5 shadow-xl hover:shadow-2xl transition-shadow"
                        >
                          <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center mb-3">
                            <Upload className="w-6 h-6 text-white" />
                          </div>
                          <h3 className="font-bold text-gray-900 mb-1">1. Upload</h3>
                          <p className="text-gray-600 text-sm">Photo or video of your pet</p>
                        </motion.div>

                        <motion.div
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.8 }}
                          className="bg-white rounded-xl p-5 shadow-xl hover:shadow-2xl transition-shadow"
                        >
                          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center mb-3">
                            <Brain className="w-6 h-6 text-white" />
                          </div>
                          <h3 className="font-bold text-gray-900 mb-1">2. AI Analyzes</h3>
                          <p className="text-gray-600 text-sm">Computer vision processing</p>
                        </motion.div>

                        <motion.div
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 1 }}
                          className="bg-white rounded-xl p-5 shadow-xl hover:shadow-2xl transition-shadow"
                        >
                          <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-lg flex items-center justify-center mb-3">
                            <Heart className="w-6 h-6 text-white" />
                          </div>
                          <h3 className="font-bold text-gray-900 mb-1">3. Get Insights</h3>
                          <p className="text-gray-600 text-sm">Detailed behavioral analysis</p>
                        </motion.div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>

        {/* What We Analyze Section */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-6">
            <div className="text-center mb-16">
              <Badge className="mb-4 px-6 py-2 bg-purple-100 text-purple-700 border-purple-200">
                AI CAPABILITIES
              </Badge>
              <h2 className="text-4xl md:text-5xl font-black mb-4 text-gray-900">
                What the AI Analyzes
              </h2>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Understanding the indicators our AI looks for when analyzing your pet's behavior
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
              {emotionExamples.map((example, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300 h-full">
                    <CardContent className="p-6">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center bg-gray-100`}>
                        <example.icon className={`w-6 h-6 ${example.color}`} />
                      </div>
                      <h3 className="font-bold text-gray-900">{example.emotion}</h3>
                      <ul className="space-y-2">
                        {example.indicators.map((indicator, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-gray-600">
                            <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                            <span>{indicator}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="mt-12 max-w-3xl mx-auto"
            >
              <Card className="border-2 border-blue-200 bg-blue-50">
                <CardContent className="p-6">
                  <div className="flex items-start gap-3">
                    <Info className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
                    <div>
                      <h4 className="font-bold text-blue-900 mb-2">Important Disclaimer</h4>
                      <p className="text-blue-800 text-sm leading-relaxed">
                        Pet Decoder AI is an educational tool that analyzes visual behavioral cues. It is NOT a medical diagnostic tool and should NEVER replace professional veterinary care. For health concerns, emergencies, or medical advice, always consult a licensed veterinarian.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>

        {/* How It Works Section */}
        <section id="how-it-works" className="py-20 bg-gradient-to-br from-gray-50 to-purple-50">
          <div className="container mx-auto px-6">
            <div className="text-center mb-16">
              <Badge className="mb-4 px-6 py-2 bg-purple-100 text-purple-700 border-purple-200">
                HOW IT WORKS
              </Badge>
              <h2 className="text-4xl md:text-5xl font-black mb-4 text-gray-900">
                Simple 4-Step Process
              </h2>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                From upload to insights in under a minute
              </p>
            </div>

            <div className="max-w-5xl mx-auto">
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {howItWorks.map((step, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="relative"
                  >
                    {index < howItWorks.length - 1 && (
                      <div className="hidden lg:block absolute top-16 left-[60%] w-[80%] h-0.5 bg-gradient-to-r from-purple-300 to-blue-300" />
                    )}

                    <Card className="border-none shadow-xl hover:shadow-2xl transition-all duration-300 bg-white h-full">
                      <CardContent className="p-6 text-center relative">
                        <div className={`w-16 h-16 bg-gradient-to-br ${step.color} rounded-xl flex items-center justify-center mx-auto shadow-xl transform hover:scale-110 transition-transform duration-300`}>
                          <step.icon className="w-8 h-8 text-white" />
                        </div>
                        <div className="absolute -top-3 -right-3 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-xl border-4 border-purple-100">
                          <span className="text-xl font-black text-purple-600">{step.step}</span>
                        </div>
                        <h3 className="text-lg font-bold mb-2 text-gray-900 mt-4">{step.title}</h3>
                        <p className="text-gray-600 leading-relaxed text-sm mb-3">{step.description}</p>
                        <Badge variant="outline" className="text-xs">
                          {step.detail}
                        </Badge>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="mt-12 text-center"
              >
                <Button
                  onClick={handleTryNow}
                  size="lg"
                  className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white text-lg px-12 py-7 shadow-2xl hover:shadow-purple-500/50 transition-all group rounded-2xl font-bold"
                >
                  <Sparkles className="w-5 h-5 mr-2 group-hover:animate-spin" />
                  Try It Now - No Signup Required
                  <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-20 bg-white">
          <div className="container mx-auto px-6">
            <div className="text-center mb-16">
              <Badge className="mb-4 px-6 py-2 bg-green-100 text-green-700 border-green-200 shadow-lg">
                ALL FEATURES • ALWAYS FREE
              </Badge>
              <h2 className="text-4xl md:text-5xl font-black mb-4 text-gray-900">
                Everything You Need
              </h2>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Comprehensive tools for understanding your pet's behavior
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.05 }}
                  viewport={{ once: true }}
                >
                  <Card className="border-none shadow-lg hover:shadow-2xl transition-all duration-300 h-full bg-white group hover:-translate-y-2">
                    <CardContent className="p-6">
                      <div className={`w-14 h-14 bg-gradient-to-br ${feature.gradient} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg mb-4`}>
                        <feature.icon className="w-7 h-7 text-white" />
                      </div>
                      <Badge className="bg-green-100 text-green-700 font-bold border-green-200 text-xs mb-3">
                        {feature.benefit}
                      </Badge>
                      <h3 className="text-lg font-bold mb-3 text-gray-900 group-hover:text-purple-600 transition-colors">{feature.title}</h3>
                      <p className="text-gray-600 leading-relaxed text-sm">{feature.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Comparison Section */}
        <section className="py-20 bg-gradient-to-br from-gray-50 to-purple-50">
          <div className="container mx-auto px-6">
            <div className="text-center mb-16">
              <Badge className="mb-4 px-6 py-2 bg-blue-100 text-blue-700 border-blue-200">
                COMPARISON
              </Badge>
              <h2 className="text-4xl md:text-5xl font-black mb-4 text-gray-900">
                How We Compare
              </h2>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Pet Decoder AI vs. traditional behavior observation methods
              </p>
            </div>

            <div className="max-w-4xl mx-auto overflow-x-auto">
              <div className="min-w-[600px]">
                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="font-bold text-gray-900 p-4"></div>
                  <div className="font-bold text-center p-4 bg-gray-100 rounded-xl text-gray-700">
                    <div className="text-sm mb-1">Traditional Methods</div>
                    <div className="text-xs text-gray-500">Manual observation</div>
                  </div>
                  <div className="font-bold text-center p-4 bg-gradient-to-r from-purple-500 to-blue-500 rounded-xl text-white shadow-lg">
                    <div className="text-sm mb-1">Pet Decoder AI</div>
                    <div className="text-xs opacity-90">Computer vision analysis</div>
                  </div>
                </div>

                {comparisonData.map((row, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    viewport={{ once: true }}
                    className="grid grid-cols-3 gap-4 mb-3"
                  >
                    <div className="font-semibold text-gray-900 p-4 bg-gray-50 rounded-xl flex items-center">
                      {row.feature}
                    </div>
                    <div className="p-4 bg-white border border-gray-200 rounded-xl flex items-center justify-center text-gray-600 text-sm text-center">
                      {row.traditional}
                    </div>
                    <div className={`p-4 rounded-xl flex items-center justify-center text-sm text-center font-semibold ${
                      row.petDecoderBest 
                        ? 'bg-gradient-to-r from-green-50 to-emerald-50 text-green-700 border-2 border-green-200' 
                        : 'bg-white border border-gray-200 text-gray-600'
                    }`}>
                      {row.petDecoderBest && <CheckCircle className="w-4 h-4 mr-2 text-green-600 flex-shrink-0" />}
                      <span>{row.petDecoder}</span>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="mt-12 max-w-2xl mx-auto"
            >
              <Card className="border-2 border-amber-200 bg-amber-50">
                <CardContent className="p-6">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-6 h-6 text-amber-600 flex-shrink-0 mt-1" />
                    <div>
                      <h4 className="font-bold text-amber-900 mb-2">Complementary, Not a Replacement</h4>
                      <p className="text-amber-800 text-sm leading-relaxed">
                        Pet Decoder AI is designed to complement professional veterinary care and behavioral consultations, not replace them. Use insights as a starting point for understanding your pet better and communicating more effectively with professionals.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>

        {/* FAQ Section */}
        <section id="faq" className="py-20 bg-white">
          <div className="container mx-auto px-6">
            <div className="text-center mb-16">
              <Badge className="mb-4 px-6 py-2 bg-purple-100 text-purple-700 border-purple-200">
                FREQUENTLY ASKED QUESTIONS
              </Badge>
              <h2 className="text-4xl md:text-5xl font-black mb-4 text-gray-900">
                Your Questions Answered
              </h2>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Everything you need to know about Pet Decoder AI
              </p>
            </div>

            <div className="max-w-3xl mx-auto">
              <Accordion type="single" collapsible className="w-full">
                {faqs.map((faq, index) => (
                  <AccordionItem key={index} value={`item-${index}`} className="border-b border-purple-100">
                    <AccordionTrigger className="text-left hover:text-purple-600 py-5">
                      <span className="font-semibold text-lg">{faq.question}</span>
                    </AccordionTrigger>
                    <AccordionContent className="text-gray-600 leading-relaxed pb-5">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </div>
        </section>

        {/* Privacy & Security */}
        <section className="py-20 bg-gray-900 text-white relative overflow-hidden">
          <div className="absolute inset-0 bg-grid-pattern opacity-5" />
          <div className="container mx-auto px-6 relative z-10">
            <div className="max-w-5xl mx-auto">
              <div className="text-center mb-16">
                <Badge className="mb-4 px-6 py-2 bg-green-900 text-green-300 border-green-700">
                  PRIVACY & SECURITY
                </Badge>
                <h2 className="text-4xl md:text-5xl font-black mb-4">
                  Your Data, Your Control
                </h2>
                <p className="text-xl text-gray-300 max-w-2xl mx-auto">
                  Enterprise-grade security with full transparency
                </p>
              </div>

              <div className="grid md:grid-cols-3 gap-6">
                {[
                  {
                    icon: Lock,
                    title: "AES-256 Encryption",
                    description: "Military-grade encryption for data at rest and TLS 1.3 for data in transit. Your pet's data is secure.",
                    color: "from-green-500 to-emerald-500"
                  },
                  {
                    icon: Globe,
                    title: "Regulatory Compliance",
                    description: "Full GDPR, CCPA, and PIPEDA compliance. Your data is handled according to international privacy standards.",
                    color: "from-blue-500 to-cyan-500"
                  },
                  {
                    icon: Shield,
                    title: "Never Used for Training",
                    description: "Your data is NEVER used to train our AI models. What you upload stays private and is never sold or shared.",
                    color: "from-purple-500 to-pink-500"
                  }
                ].map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    viewport={{ once: true }}
                  >
                    <Card className="border-2 border-gray-700 bg-gray-800 shadow-xl hover:shadow-2xl transition-all duration-300 h-full hover:border-gray-600">
                      <CardContent className="p-6 text-center">
                        <div className={`w-16 h-16 bg-gradient-to-br ${item.color} rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg`}>
                          <item.icon className="w-8 h-8 text-white" />
                        </div>
                        <h3 className="text-xl font-bold mb-3 text-white">{item.title}</h3>
                        <p className="text-gray-300 leading-relaxed">{item.description}</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>

              <motion.div
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                className="mt-12 text-center"
              >
                <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-gray-400">
                  <Link to={createPageUrl("PrivacyPolicy")} className="hover:text-white transition-colors underline">
                    Privacy Policy
                  </Link>
                  <span>•</span>
                  <Link to={createPageUrl("TermsOfService")} className="hover:text-white transition-colors underline">
                    Terms of Service
                  </Link>
                  <span>•</span>
                  <Link to={createPageUrl("AITransparency")} className="hover:text-white transition-colors underline">
                    AI Transparency
                  </Link>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Final CTA */}
        <section className="py-24 bg-gradient-to-r from-purple-600 via-blue-600 to-purple-600 relative overflow-hidden">
          <div className="absolute inset-0 bg-grid-pattern opacity-10" />
          <div className="container mx-auto px-6 relative z-10">
            <div className="max-w-4xl mx-auto text-center text-white">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
              >
                <Badge className="mb-6 px-8 py-3 bg-white/20 backdrop-blur-sm text-white border-white/30 text-lg font-bold">
                  <Gift className="w-5 h-5 mr-2" />
                  100% Free • No Hidden Costs
                </Badge>
                <h2 className="text-4xl md:text-6xl font-black mb-6 leading-tight">
                  Ready to Understand Your Pet Better?
                </h2>
                <p className="text-xl md:text-2xl mb-10 opacity-95 leading-relaxed">
                  Join pet parents using AI to decode behavior and build stronger bonds with their furry friends
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button
                    onClick={handleTryNow}
                    size="lg"
                    className="bg-white text-purple-600 hover:bg-gray-100 text-xl px-14 py-8 shadow-2xl hover:shadow-white/50 transition-all duration-300 group rounded-2xl font-black"
                  >
                    <Sparkles className="w-6 h-6 mr-2 group-hover:animate-spin" />
                    Try Now - No Signup
                    <ArrowRight className="w-6 h-6 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                  <Button
                    onClick={handleGetStarted}
                    size="lg"
                    variant="outline"
                    className="text-xl px-14 py-8 border-2 border-white/30 bg-white/10 backdrop-blur-sm text-white hover:bg-white/20 font-bold rounded-2xl"
                  >
                    Sign Up for Full Access
                  </Button>
                </div>
                <p className="text-base mt-6 opacity-80">No credit card • Try immediately • All features free</p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-white border-t border-purple-100 py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-4 gap-8">
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <AppLogo size="sm" />
                  <span className="font-bold text-lg">Pet Decoder AI</span>
                </div>
                <p className="text-gray-600 text-sm mb-4">
                  AI-powered pet behavior analysis to help you understand your pet better.
                </p>
                <Badge className="bg-green-100 text-green-700 border-green-200">
                  <Gift className="w-3 h-3 mr-1" />
                  100% Free
                </Badge>
              </div>

              <div>
                <h3 className="font-semibold mb-4">Product</h3>
                <ul className="space-y-2 text-sm">
                  <li>
                    <button
                      onClick={handleTryNow}
                      className="text-gray-600 hover:text-purple-600 transition-colors"
                    >
                      Try It Now
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
                      className="text-gray-600 hover:text-purple-600 transition-colors"
                    >
                      Features
                    </button>
                  </li>
                  <li>
                    <Link
                      to={createPageUrl("AITransparency")}
                      className="text-gray-600 hover:text-purple-600 transition-colors"
                    >
                      AI Transparency
                    </Link>
                  </li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold mb-4">Legal</h3>
                <ul className="space-y-2 text-sm">
                  <li>
                    <Link
                      to={createPageUrl("PrivacyPolicy")}
                      className="text-gray-600 hover:text-purple-600 transition-colors"
                    >
                      Privacy Policy
                    </Link>
                  </li>
                  <li>
                    <Link
                      to={createPageUrl("TermsOfService")}
                      className="text-gray-600 hover:text-purple-600 transition-colors"
                    >
                      Terms of Service
                    </Link>
                  </li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold mb-4">Contact</h3>
                <ul className="space-y-2 text-sm">
                  <li>
                    <Link
                      to={createPageUrl("Contact")}
                      className="text-gray-600 hover:text-purple-600 transition-colors"
                    >
                      Get in Touch
                    </Link>
                  </li>
                </ul>
              </div>
            </div>

            <div className="mt-8 pt-8 border-t border-gray-200 text-center text-sm text-gray-600">
              <p>© {new Date().getFullYear()} Pet Decoder AI. All rights reserved.</p>
              <p className="mt-2">GDPR, CCPA & PIPEDA Compliant • AES-256 Encrypted • 100% Free</p>
            </div>
          </div>
        </footer>

        <style>{`
          .bg-grid-pattern {
            background-image: linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px);
            background-size: 20px 20px;
          }

          .animate-gradient {
            animation: gradient 3s ease infinite;
          }

          @keyframes gradient {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
          }
        `}</style>
      </div>
    </>
  );
}
