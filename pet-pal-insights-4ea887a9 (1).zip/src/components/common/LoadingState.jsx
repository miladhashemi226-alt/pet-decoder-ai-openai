import React from "react";
import { Loader2 } from "lucide-react";
import { motion } from "framer-motion";

export default function LoadingState({ 
  message = "Loading...", 
  size = "default",
  fullScreen = false 
}) {
  const sizeClasses = {
    sm: "w-6 h-6",
    default: "w-12 h-12",
    lg: "w-16 h-16"
  };

  const containerClasses = fullScreen
    ? "min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 flex items-center justify-center"
    : "flex items-center justify-center py-12";

  return (
    <div className={containerClasses}>
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="text-center"
      >
        <div className="relative inline-block mb-4">
          <div className={`${sizeClasses[size]} rounded-full border-4 border-purple-100 absolute inset-0`}></div>
          <Loader2 
            className={`${sizeClasses[size]} text-purple-600 animate-spin relative`}
            aria-label="Loading"
          />
        </div>
        {message && (
          <p className="text-gray-600 font-medium animate-pulse">{message}</p>
        )}
      </motion.div>
    </div>
  );
}